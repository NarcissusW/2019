let express = require('express');
let router = express.Router();
let User = require('../models/User');
let Password = require('../models/Password');
let ChatContent = require('../models/ChatContent');
let ChatRelation = require('../models/ChatRelation');
const crypto = require('crypto');
let mongoose = require('mongoose');

let responseData;

router.use((res, req, next) => {
    responseData = {
        code: 0,
        msg: ''
    };
    next();
});

router.post('/user/register', (req, res, next) => {
    let username = req.body.username;
    let password = req.body.password;
    let repassword = req.body.repassword;
    //用户名不为空
    if (username === '') {
        responseData.code = 1;
        responseData.msg = '用户名不能为空';
        res.json(responseData);
        return;
    }
    //密码不为空
    if (password === '') {
        responseData.code = 2;
        responseData.msg = '密码不能为空';
        res.json(responseData);
        return;
    }
    //两次密码一致
    if (password !== repassword) {
        responseData.code = 3;
        responseData.msg = '两次密码必须一致!';
        res.json(responseData);
        return;
    }
    //用户名是否已存在
    User.findOne({
        username: username
    }).then((userInfo) => {
        if (userInfo) {
            responseData.code = 4;
            responseData.msg = '用户名已存在';
            res.json(responseData);
            return;
        }
        password = crypto.createHmac('sha256', password)
            .update('juju')
            .digest('hex');
        let psd = new Password({
            username: username,
            password: password
        });
        let avater = "https://chat.mu-mo.top/public/avatar/avatar" + parseInt(1 + Math.random() * 10) +
            ".jpeg"
        let user = new User({
            username,
            avater
        });
        psd.save().then(() => {
            return user.save(() => {
                responseData.msg = '注册成功';
                res.json(responseData);

                User.findOne({
                    username: "仿生鲸"
                }).then(robotUserInfo => {
                    if (!robotUserInfo) {
                        new User({
                            _id: mongoose.Types.ObjectId("5d077a756bc6f5267b2e815c"),
                            isAdmin: true,
                            username: "仿生鲸",
                            avater: "https://chat.mu-mo.top/public/avatar/bot.jpeg",
                            signature: "我是智能机器人仿生鲸",
                        }).save()
                        new Password({
                            username: "仿生鲸",
                            password: crypto.createHmac('sha256', "sdfasfdasdfasdfasdfasf")
                                .update('juju')
                                .digest('hex')
                        }).save()
                    }
                });
                User.findOne({
                    username: username
                }).then((newUserInfo) => {
                    if (newUserInfo) {
                        // console.log(newUserInfo);
                        const chatContentID = mongoose.Types.ObjectId();
                        new ChatContent({
                            _id: chatContentID,
                            unread: true,
                            chatWith: newUserInfo._id,
                            user_id: mongoose.Types.ObjectId("5d077a756bc6f5267b2e815c"),
                            content: "我是智能机器人仿生鲸",
                            addTime: Date.now(),
                        }).save(() => {
                            new ChatRelation({
                                chatContent: [chatContentID],
                                userA: newUserInfo._id,
                                userB: mongoose.Types.ObjectId("5d077a756bc6f5267b2e815c"),
                            }).save();
                        });
                    }
                });
            });
        });
    });
});

router.post('/user/login', (req, res, next) => {
    let username = req.body.username;
    let password = req.body.password;
    let id;
    if (username === '' || password === '') {
        responseData.code = 1;
        responseData.msg = '用户名或密码不能为空';
        res.json(responseData);
        return;
    }
    password = crypto.createHmac('sha256', password)
        .update('juju')
        .digest('hex');
    Password.findOne({
        username: username,
        password: password
    }).then((rs) => {
        if (!rs) {
            responseData.code = 2;
            responseData.msg = '用户名不存在或密码错误';
            res.json(responseData);
            return
        }
        responseData.msg = '登录成功';
        User.findOne({
            username: username
        }).then((userInfo) => {
            responseData.userInfo = {
                _id: userInfo._id,
                username: userInfo.username
            };
            req.session.userInfo = {
                _id: userInfo._id
            };
            res.json(responseData);
            return 0;
        })
    })
});
router.get('/user/logout', (req, res, ) => {
    req.session.userInfo = null;
    res.json(responseData);
});

module.exports = router;