cd /app
node app.js