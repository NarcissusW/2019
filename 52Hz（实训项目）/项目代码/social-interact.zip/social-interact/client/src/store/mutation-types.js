
export const SET_USERINFO = 'set_userInfo';

export const SET_IMGDATA = 'set_imgdata';

export const SET_CMESSAGE = 'set_cmessage';

export const UPDATE_CUNREAD = 'update_cunread';

export const SET_CUNREAD = 'set_cunread';

export const CLEAR_CUNREAD = 'clear_cunread';

export const SET_CHATLIST = 'set_chatList';

export const UPDATE_CHATLIST = 'update_chatList';

export const CLEAR_CHATUNREAD = 'clear_chatUnread';

export const SET_RESIZE = 'set_resize';

export const RESET_RESIZE = 'reset_resize';
