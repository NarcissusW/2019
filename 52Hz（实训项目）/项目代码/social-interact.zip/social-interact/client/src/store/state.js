const state = {
  userInfo:{},
  imgdata:{},
  cmessage:{},
  cunread:0,
  unread:0,
  chatList:[],
  isResize:false
};

export default state
